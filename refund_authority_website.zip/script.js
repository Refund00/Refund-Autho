if (location.pathname.includes("admin.html") && localStorage.getItem("loggedIn") !== "true") {
  alert("Access denied. Please login first.");
  location.href = "login.html";
}

function logout() {
  localStorage.removeItem("loggedIn");
  location.href = "login.html";
}

let cases = JSON.parse(localStorage.getItem("cases")) || {};

function renderCases() {
  const table = document.getElementById("caseTable");
  if (table) {
    table.innerHTML = "";
    for (let id in cases) {
      const row = document.createElement("tr");
      row.innerHTML = \`
        <td>\${id}</td>
        <td>\${cases[id]}</td>
        <td>
          <button onclick="editCase('\${id}')">Edit</button>
          <button onclick="deleteCase('\${id}')">Delete</button>
        </td>
      \`;
      table.appendChild(row);
    }
  }
}

document.getElementById("caseForm")?.addEventListener("submit", function(e) {
  e.preventDefault();
  const id = document.getElementById("caseID").value;
  const status = document.getElementById("status").value;
  cases[id] = status;
  localStorage.setItem("cases", JSON.stringify(cases));
  renderCases();
  e.target.reset();
});

function editCase(id) {
  document.getElementById("caseID").value = id;
  document.getElementById("status").value = cases[id];
}

function deleteCase(id) {
  delete cases[id];
  localStorage.setItem("cases", JSON.stringify(cases));
  renderCases();
}

if (document.getElementById("trackForm")) {
  document.getElementById("trackForm").addEventListener("submit", function(e) {
    e.preventDefault();
    const inputID = document.getElementById("caseID").value.trim();
    const resultBox = document.getElementById("caseResult");
    if (cases[inputID]) {
      resultBox.innerHTML = \`<p>Status for <strong>\${inputID}</strong>: <span class="status">\${cases[inputID]}</span></p>\`;
    } else {
      resultBox.innerHTML = \`<p>❌ Case ID <strong>\${inputID}</strong> not found.</p>\`;
    }
  });
}

renderCases();
